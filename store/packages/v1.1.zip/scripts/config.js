let actions = {
    nothing: 'nothing',
    play: 'play',
    pause: 'pause',
    stop: 'stop',
    next: 'next',
    prev: 'prev',
    like: 'like',
    comments: 'comments',
    reset: 'reset',
}

let events = {
    ended: 'ended',
    play: 'play',
    pause: 'pause',
    stop: 'stop',
    next: 'next',
    prev: 'prev',
    double_play: 'double_play',
    double_stop: 'double_stop',
}

let settings = {
    event_action_map: {
        ended: [actions.next],
        play: [actions.play],
        pause: [actions.pause],
        stop: [actions.stop],
        next: [actions.next],
        prev: [actions.prev],
        double_play: [actions.like],
        double_stop: [actions.comments],
    },
}

function loadSettings(onLoad) {
    chrome.storage.sync.get(["settings"]).then((result) => {
        if (result.settings) {
            settings = result.settings;
        }
        onLoad(settings);
    });
}

function saveSettings(onSave) {
    chrome.storage.sync.set({ settings: settings }).then(onSave);
}