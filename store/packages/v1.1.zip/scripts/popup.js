
loadSettings(() => {
    let action_map_editor = document.getElementById("event_action_map");

    for (let event in events) {

        let div = document.createElement("div");
        div.className = "event-action-pair";

        let label = document.createElement("label");
        label.innerText = event_string_map[event];
        label.htmlFor = `select_${event}`;
        label.className = "event-label";

        let select = document.createElement("select");
        select.id = `select_${event}`;
        select.name = `select_${event}`;
        select.className = "action-select";
        select.addEventListener("change", onEventActionChange)

        for (let action in actions) {
            let option = document.createElement("option");
            option.value = action;
            option.text = action_string_map[action];
            option.className = "action";
            select.appendChild(option);
            if (settings.event_action_map[event] && settings.event_action_map[event].includes(action)) {
                option.selected = true;
            }
        }

        div.appendChild(label);
        div.appendChild(select);
        action_map_editor.appendChild(div);

    }

    let reset_button = document.getElementById("reset");
    reset_button.addEventListener("click", resetSettings);
})

function onEventActionChange() {
    let new_event_action_map = {};
    for (let event in events) {
        let select = document.getElementById(`select_${event}`);
        new_event_action_map[event] = Array.from(select.selectedOptions).map(option => option.value);
    }
    settings.event_action_map = new_event_action_map;
    saveSettings();
}

function resetSettings() {
    settings = {
        event_action_map: {
            ended: [actions.next],
            play: [actions.play],
            pause: [actions.pause],
            stop: [actions.stop],
            next: [actions.next],
            prev: [actions.prev],
            double_play: [actions.like],
            double_stop: [actions.comments],
        },
    }
    saveSettings(() => {
        location.reload();
    });
}