let action_string_map = {
    nothing: 'Do Nothing',
    play: 'Play',
    pause: 'Pause',
    stop: 'Stop',
    next: 'Next Video',
    prev: 'Previous Video',
    like: 'Like Video',
    comments: 'Toggle Comments',
    reset: 'Go to video start'
}

let event_string_map = {
    ended: 'Video Ended',
    play: 'Video Played',
    pause: 'Video Paused',
    stop: 'Video Stopped',
    next: 'Next Track',
    prev: 'Previous Track',
    double_play: 'Double Play',
    double_stop: 'Double Stop',
}
