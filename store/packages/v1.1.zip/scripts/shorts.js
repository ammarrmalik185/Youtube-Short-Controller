let video;

const NEAR_END_THRESHOLD = 0.5; // seconds
const DOUBLE_CLICK_THRESHOLD = 500; // milliseconds

let double_click_active = false
let double_stop_active = false;

let comments_open = false;

function hookShortsVideo() {

    video.addEventListener('timeupdate', onVideoTimeUpdate);
    video.addEventListener('timeupdate', hookNextPrevListeners);
    hookNextPrevListeners();

    // Functions
    function hookNextPrevListeners(){
        if ('mediaSession' in navigator) {
            navigator.mediaSession.setActionHandler("play", () => handleEvent(events.play))
            navigator.mediaSession.setActionHandler("pause", () => handleEvent(events.pause));
            navigator.mediaSession.setActionHandler("stop", () => {
                console.log("[YTShortEnhancer] Stop intercepted");
                handleEvent(events.stop);

                // Undo YouTube’s forced stop (prevent video reset)
                setTimeout(() => {
                    video.play().catch(() => {});
                }, 1);

            });
            navigator.mediaSession.setActionHandler('nexttrack', () => handleEvent(events.next));
            navigator.mediaSession.setActionHandler('previoustrack', () => handleEvent(events.prev));
        }
    }

    // Events
    function onVideoTimeUpdate(event) {
        const video = event.currentTarget;
        if (!video || !isFinite(video.duration) || video.duration === 0) return;
        const remaining = video.duration - video.currentTime;
        if (remaining <= NEAR_END_THRESHOLD) {
            handleEvent(events.ended);
        }
    }

}

function handleEvent(event) {

    loadSettings(settings => {
        const action_list = settings.event_action_map[event];
        if (action_list) {
            action_list.forEach(action => {
                switch (action) {
                    case actions.play: doPlay(); break;
                    case actions.pause: doPause(); break;
                    case actions.stop: doStop(); break;
                    case actions.next: doNext(); break;
                    case actions.prev: doPrev(); break;
                    case actions.like: doLike(); break;
                    case actions.comments: toggleComments(); break;
                    case actions.reset: video.currentTime = 0; break;
                    case actions.nothing: /* Do nothing */ break;
                    default: log(`Unknown action: ${action}`);
                }
            });
        } else {
            log(`No actions mapped for event: ${event}`);
        }
    })



    // Actions
    function doPlay(){
        if (video.paused) {
            log("Playing video");
            video.play();
        } else {
            log("Video already playing");
        }
        checkDoubleClick();
    }
    function doPause(){
        if (!video.paused) {
            log("Pausing video");
            video.pause();
        } else {
            log("Video already paused");
        }
        checkDoubleClick();
    }
    function doStop(){
        video.pause();
        checkStopDoubleClick();
    }
    function doNext(){
        const nextButton = document.querySelector('#navigation-button-down > ytd-button-renderer > yt-button-shape > button');
        if (nextButton) {
            log("Moving to next video");
            nextButton.click();
        }
    }
    function doPrev(){
        const prevButton = document.querySelector('#navigation-button-up > ytd-button-renderer > yt-button-shape > button');
        if (prevButton) {
            log("Moving to previous video");
            prevButton.click();
        }
    }
    function doLike(){
        const like_button = document.querySelector("#like-button > yt-button-shape > label > button");
        if (like_button) {
            log("Liking video");
            like_button.click();
        }
    }
    function toggleComments(){
        const comment_button = document.querySelector("#comments-button > ytd-button-renderer > yt-button-shape > label > button");
        const comment_button_close = document.querySelector("#visibility-button > ytd-button-renderer > yt-button-shape > button");

        if (comments_open){
            if (comment_button_close){
                log("Closing comments section");
                comment_button_close.click();
                comments_open = false;
            }
        } else {
            if (comment_button) {
                log("Opening comments section");
                comment_button.click();
                comments_open = true;
            }
        }
    }
}

function checkDoubleClick(){
    if (double_click_active) {
        handleEvent(events.double_play)
        double_click_active = false;
    } else {
        double_click_active = true;
        setTimeout(() => {
            double_click_active = false;
        }, DOUBLE_CLICK_THRESHOLD)
    }
}

function checkStopDoubleClick(){
    if (double_stop_active) {
        handleEvent(events.double_stop)
        double_stop_active = false;
    } else {
        double_stop_active = true;
        setTimeout(() => {
            double_stop_active = false;
        }, DOUBLE_CLICK_THRESHOLD)
    }
}

function log(msg) {
    // console.log(`[YTShortEnhancer] ${msg}`);
}

setInterval(() => {
    const newVideo = document.querySelector('video');
    if (newVideo && newVideo !== video) {
        video = newVideo;
        hookShortsVideo();
    }
}, 100)
